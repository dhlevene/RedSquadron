#!/bin/bash
unix2dos -q return-linefeed.pl0
unix2dos -q return-linefeed.log
