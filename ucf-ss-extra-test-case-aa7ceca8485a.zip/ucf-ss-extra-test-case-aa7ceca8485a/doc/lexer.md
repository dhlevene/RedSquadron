# lexer (project-1)
## Extra Test Cases
### basic.pl0
   This test case has no any tricky part, just to make sure your scanner and lexer is working minimally.
   This is helpful to adjust the formatting.
### space.pl0
   This test case contains some token with/without whitespace between other token, can you pass it?
### comment.pl0
   This test case start to introduce comment, make sure the comment are replaced by exact number of whitespace.
### comment2.pl0
   This test case has a non-closing comment block at the end, do you care about it?
### compact.pl0
   This test case in written in a single line, do you rely on the newline?
### no-newline.pl0
   This test case in written in a single 'line', ... but without the ending linefeed, is your program waiting input forever?
### return-linefeed.pl0
   Unlike other test case, this one is using CRLF instead of LF, not a big deal right?
### too-big.pl0
   This test case has numeric value that excess the upper limit.
### too-long.pl0
   This test case has identifier that has too long name.
###  too-long.pl0
   This test case has identifier that has too long name.

