The detailed project description is on the wiki page:

https://bitbucket.org/schneider128k/2016_fall_2016_cop3402/wiki/Project_0_PM0_Virtual_Machine
