void error(char *);
void log(char *);
