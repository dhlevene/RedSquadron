#include <stdio.h>

void message(char *msg) {
  printf("%s\n", msg);
}


void error(char *err) {
  printf("%s\n", err);
}
