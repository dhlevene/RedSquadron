To run the lexer:

`gcc lex.c run-lex.c`
`./a.out < ex1.txt`

The file run-lex.c contains the main method. It reads input from stdin and repeatedly calls the function lex() that is defined in lex.c and prints out the recognized tokens.  



